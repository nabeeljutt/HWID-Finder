Open HWID Finder
Copy the Code Email Us.